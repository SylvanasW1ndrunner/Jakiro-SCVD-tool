import torch
import torch.nn as nn

class RNN_Model(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim):
        super(RNN_Model, self).__init__()
        self.rnn = nn.RNN(input_dim, hidden_dim, batch_first=True)
        self.fc = nn.Linear(hidden_dim, 1)  # 1 output for binary classification
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        _, h_n = self.rnn(x)
        x = self.fc(h_n[-1])
        x = self.sigmoid(x)  # Sigmoid activation for binary classification
        return x
